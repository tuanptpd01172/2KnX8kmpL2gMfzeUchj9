<?php include_once('inc/header.php') ?>

<!-- banner -->
    <div class="banner1 jarallax">
    </div>
<!-- //banner -->   
<!-- icons -->
<!-- //icons -->	
<!-- footer -->
	<?php include_once('inc/footer.php') ?>