<?php include_once('inc/header.php') ?>


		<div class="slider">
			<ul id="sb-slider" class="sb-slider">
				<li>
					<a href="#"><img src="images/11.jpg" alt="image1"/></a>
					<div class="sb-description">
						<h2><span>IF</span>We provide best design</h2>
						<h4>We provide best Interior living rooms</h4>
						<div class="w3ls-button">
							<a href="#" data-toggle="modal" data-target="#myModal">More About Our Designs</a>
						</div>
					</div>
				</li>
				<li>
					<a href="#"><img src="images/22.jpg" alt="image2"/></a>
					<div class="sb-description">
						<h3><span>IF</span>We provide best design</h3>
						<h4>We provide best Interior living rooms</h4>
						<div class="w3ls-button">
							<a href="#" data-toggle="modal" data-target="#myModal">More About Our Designs</a>
						</div>
					</div>
				</li>
				<li>
					<a href="#"><img src="images/33.jpg" alt="image1"/></a>
					<div class="sb-description">
						<h3><span>IF</span>We provide best design</h3>
						<h4>We provide best Interior living rooms</h4>
						<div class="w3ls-button">
							<a href="#" data-toggle="modal" data-target="#myModal">More About Our Designs</a>
						</div>
					</div>
				</li>
				<li>
					<a href="#"><img src="images/44.jpg" alt="image1"/></a>
					<div class="sb-description">
						<h3><span>IF</span>We provide best design</h3>
						<h4>We provide best Interior living rooms</h4>
						<div class="w3ls-button">
							<a href="#" data-toggle="modal" data-target="#myModal">More About Our Designs</a>
						</div>
					</div>
				</li>
				<li>
					<a href="#"><img src="images/55.jpg" alt="image1"/></a>
					<div class="sb-description">
						<h3><span>IF</span>We provide best design</h3>
						<h4>We provide best Interior living rooms</h4>
						<div class="w3ls-button">
							<a href="#" data-toggle="modal" data-target="#myModal">More About Our Designs</a>
						</div>
					</div>
				</li>
				<li>
					<a href="#"><img src="images/33.jpg" alt="image1"/></a>
					<div class="sb-description">
						<h3><span>IF</span>We provide best design</h3>
						<h4>We provide best Interior living rooms</h4>
						<div class="w3ls-button">
							<a href="#" data-toggle="modal" data-target="#myModal">More About Our Designs</a>
						</div>
					</div>
				</li>
			</ul>

			<div id="nav-arrows" class="nav-arrows">
				<a href="#">Next</a>
				<a href="#">Previous</a>
			</div>
			<div class="agile_banner_social">
				<ul class="agileits_social_list">
					<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
				</ul>
			</div>
		</div>
	
<!-- //banner -->	

<!-- agile-about -->
	<div class="jarallax agile-about w3ls-section">
		<div class="container">
			<h2 class="w3ls_head"><span>Wel</span>come</h2>
					<!-- <p class="w3agile">While designing your living room, it’s a good idea to think about certain key aspects like space available, the colours to be used, the kind of furniture and accessories you fancy.</p> -->
			<div class="agile-about-grids">
					
				<div class="col-md-6 col-sm-6 agile-about-grid agile-about-grid1 " >
					<h5>Welcome To Topiary</h3>
					<h4>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</h4>
					<p>sed do eiusmod	tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
				</div>

				<div class="col-md-6 col-sm-6 agile-about-grid agile-about-grid2 " >
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="about-info-grids">
				<div class="col-md-4 col-sm-4 about-info about-info1">
					<i class="fa fa-info-circle agile-sicon" aria-hidden="true"></i>
					<h4>how we work</h4>
					<div class="h4-underline"></div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
					</div>
				<div class="col-md-4 col-sm-4 about-info about-info2">
					<i class="fa fa-question-circle agile-sicon" aria-hidden="true"></i>
					<h4>what we do</h4>
					<div class="h4-underline"></div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
					</div>
				<div class="col-md-4 col-sm-4 about-info about-info3">
					<i class="fa fa-registered agile-sicon" aria-hidden="true"></i>
					<h4>why choose us</h4>
					<div class="h4-underline"></div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
					</div>
				<div class="clearfix"></div>
			</div>
			
		</div>
	</div>
<!-- //agile-about -->

<!--/welcome-->
	<div class="w3agile welcome" id="about"> 
		<div class="container">
			<!-- <h3 class="wthree_head"><i class="fa fa-pagelines" aria-hidden="true"></i>About US</h3> -->
			<h3 class="w3ls_head"><span class="thr">About </span>US</h3>
			<div class="w3l_gallery_grids">
				<div class="col-md-6 col-xs-12 banner_bottom_left">
					<h3>Welcome to Topiary</h3>
					<p><i>Ut enim ad minima veniam</i> Quis nostrum exercitationem ullam corporis suscipit 
						laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure 
						reprehenderit qui in ea voluptate.
						vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>
					<!-- <div class="read"><a href="#" data-toggle="modal" data-target="#myModal" class="hvr-rectangle-in">Read More</a></div> -->
				</div>
				<div class="col-md-6 col-xs-12 banner_bottom_right">
					<div class="row">
						<div class="agile_w3l_info_gds col-md-6 col-sm-6 col-xs-12">
							<div class="banner_bottom_right_grid">
								<div class="view view-tenth">
								<img src="images/a1.jpg" class="img-responsive" alt="">
									
									<div class="mask">
										 <a href="#">
											  <div class="agile_text_box">
													<i class="fa fa-pagelines" aria-hidden="true"></i>
													<h3>Topiary</h3>
													
											  </div>
										 </a>
									</div>
								</div>
							</div>
							<div class="banner_bottom_right_grid">
								<div class="view view-tenth">
								<img src="images/a2.jpg" class="img-responsive" alt="">
									
									<div class="mask">
									   <a href="#">
											<div class="agile_text_box">
												<i class="fa fa-pagelines" aria-hidden="true"></i>
												<h3>Topiary</h3>
												
											</div>
										</a>
									</div>
								</div>
							</div>
						   <div class="clearfix"> </div>
						</div>
						<div class="agile_w3l_info_gds col-md-6 col-sm-6 col-xs-12 two">
							<div class="banner_bottom_right_grid">
								<div class="view view-tenth">
								<img src="images/a3.jpg" class="img-responsive" alt="">
									
									<div class="mask">
										 <a href="#">
											  <div class="agile_text_box">
													<i class="fa fa-pagelines" aria-hidden="true"></i>
													<h3>Topiary</h3>
													
											  </div>
										 </a>
									</div>
								</div>
							</div>
							<div class="banner_bottom_right_grid">
								<div class="view view-tenth">
								<img src="images/a4.jpg" class="img-responsive" alt="">
									
									<div class="mask">
									   <a href="#">
											<div class="agile_text_box">
												<i class="fa fa-pagelines" aria-hidden="true"></i>
											<h3>Topiary</h3>
												
											</div>
										</a>
									</div>
								</div>
							</div>
						   <div class="clearfix"> </div>
						</div>
					</div>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>	
	</div>
<!--//welcome-->

<!-- special -->
	<div class="special jarallax">
		<div class="container">
		<h3 class="w3ls_head"><span class="thr">Our </span>Features</h3>
					<p class="w3agile fru">While designing your living room, it’s a good idea to think about certain key aspects like space available, the colours to be used, the kind of furniture and accessories you fancy.
				</p>
			<div class="special-grids">
				<div class="col-md-6 w3l-special-grid">
					<div class="col-md-6 w3ls-special-img">
						
					</div>
					<div class="col-md-6 agileits-special-info">
						<h4>Plumbing</h4>
						<p>Maecenas ac hendrerit purus. Lorem ipsum dolor sit amet</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-6 w3l-special-grid">
					<div class="col-md-6 w3ls-special-img wthree-img1">
						
					</div>
					<div class="col-md-6 agileits-special-info">
						<h4>Roof</h4>
						<p>Maecenas ac hendrerit purus. Lorem ipsum dolor sit amet</p>
					</div>
					<div class="clearfix"> </div>
				</div>
					<div class="col-md-6 w3l-special-grid">
					<div class="col-md-6 agileits-special-info">
						<h4>Electrical</h4>
						<p>Maecenas ac hendrerit purus. Lorem ipsum dolor sit amet</p>
					</div>
					<div class="col-md-6 w3ls-special-img wthree-img2">
						
					</div>
					
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-6 w3l-special-grid">
					<div class="col-md-6 agileits-special-info">
						<h4>Structure</h4>
						<p>Maecenas ac hendrerit purus. Lorem ipsum dolor sit amet</p>
					</div>
					<div class="col-md-6 w3ls-special-img wthree-img3">
						
					</div>
				
					<div class="clearfix"> </div>
				</div>
				
				
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //special -->

<!-- testimonials -->
	<div class="testimonials jarallax">
		<div class="container">
			<h3 class="w3ls_head"><span>Our </span>Client Say</h3>
			<p class="w3agile">While designing your living room, it’s a good idea to think about certain key aspects like space available, the colours to be used, the kind of furniture and accessories you fancy.
				</p>
				
			<div class="w3ls_testimonials_grids">
				 <section class="center slider">
						<div class="agileits_testimonial_grid">
							<div class="w3l_testimonial_grid">
								<p>In eu auctor felis, id eleifend dolor. Integer bibendum dictum erat, 
									non laoreet dolor.</p>
								<h4>Rosy Crisp</h4>
								<h5>Lorem</h5>
								<div class="w3l_testimonial_grid_pos">
									<img src="images/1.png" alt=" " class="img-responsive" />
								</div>
							</div>
						</div>
						<div class="agileits_testimonial_grid">
							<div class="w3l_testimonial_grid">
								<p>In eu auctor felis, id eleifend dolor. Integer bibendum dictum erat, 
									non laoreet dolor.</p>
								<h4>Laura Paul</h4>
								<h5>Lorem</h5>
								<div class="w3l_testimonial_grid_pos">
									<img src="images/2.png" alt=" " class="img-responsive" />
								</div>
							</div>
						</div>
						<div class="agileits_testimonial_grid">
							<div class="w3l_testimonial_grid">
								<p>In eu auctor felis, id eleifend dolor. Integer bibendum dictum erat, 
									non laoreet dolor.</p>
								<h4>Michael Doe</h4>
								<h5>Lorem</h5>
								<div class="w3l_testimonial_grid_pos">
									<img src="images/1.png" alt=" " class="img-responsive" />
								</div>
							</div>
						</div>
				</section>
			</div>
		</div>
	</div>
<!-- //testimonials -->

<!-- team -->
	<!-- <div class="team">
		<div class="container">
			<h3 class="w3ls_head"><span>Our </span>Team</h3>
			<p class="w3agile">While designing your living room, it’s a good idea to think about certain key aspects like space available, the colours to be used, the kind of furniture and accessories you fancy.
				</p>
			<div class="agileits_team_grids">
				<div class="col-md-4 agileits_team_grid">
					<div class="agileits_team_grid_figure">
						<img src="images/t1.jpg" alt=" " class="img-responsive" />
					</div>
					<h4>Jane Nguyen</h4>
					<p>General Manager</p>
					<p>+21 345 287 4556</p>
					<div class="social-icon">
						<a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> 
						<a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a>
						<a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a> 
						<a href="#" class="social-button dribbble"><i class="fa fa-dribbble"></i></a> 
					</div>
				</div>
				<div class="col-md-4 agileits_team_grid">
					<div class="agileits_team_grid_figure">
						<img src="images/t2.jpg" alt=" " class="img-responsive" />
					</div>
					<h4>James Doe</h4>
					<p>Finance Executive</p>
					<p>+21 345 287 4556</p>
					<div class="social-icon">
						<a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> 
						<a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a>
						<a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a> 
						<a href="#" class="social-button dribbble"><i class="fa fa-dribbble"></i></a> 
					</div>
				</div>
				<div class="col-md-4 agileits_team_grid">
					<div class="agileits_team_grid_figure">
						<img src="images/t3.jpg" alt=" " class="img-responsive" />
					</div>
					<h4>Laura Carl</h4>
					<p>Management</p>
					<p>+21 345 287 4556</p>
					<div class="social-icon">
						<a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> 
						<a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a>
						<a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a> 
						<a href="#" class="social-button dribbble"><i class="fa fa-dribbble"></i></a> 
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div> -->
<!-- //team -->

<?php include_once('inc/footer.php') ?>