<?php include_once('inc/header.php') ?>
<!-- banner -->
	<div class="banner1 jarallax">
		
	</div>
<!-- //banner -->	
<!-- services -->
<div class="service-w3l">
	<div class="container">
		<h2 class="w3ls_head"><span>Serv</span>ices</h2>
			<p class="w3agile">While designing your living room, it’s a good idea to think about certain  key aspects like space available, the colours to be used, the kind of furniture and accessories you fancy.
				</p>
		<div class="service-grids">
			<div class="col-xs-4 ser-grid">
				<div class="ser-top">
					<div class="con hvr-shutter-in-horizontal">
						<i class="fa fa-cubes" aria-hidden="true"></i>
					</div>
					<h4>Interior Designs</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
				</div>
			</div>
			<div class="col-xs-4 ser-grid">
				<div class="ser-top">
					<div class="con hvr-shutter-in-horizontal">
						<i class="fa fa-home" aria-hidden="true"></i>
					</div>
					<h4>Exterior Designs</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
				</div>
			</div>
			<div class="col-xs-4 ser-grid">
				<div class="ser-top">
					<div class="con hvr-shutter-in-horizontal">
						<i class="fa fa-clone" aria-hidden="true"></i>
					</div>
					<h4>Interior Designs</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="service-grids ser2">
			<div class="col-xs-4 ser-grid">
				<div class="ser-top">
					<div class="con hvr-shutter-in-horizontal">
						<i class="fa fa-gavel" aria-hidden="true"></i>
					</div>
					<h4>Exterior Designs</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
				</div>
			</div>
			<div class="col-xs-4 ser-grid">
				<div class="ser-top">
					<div class="con hvr-shutter-in-horizontal">
						<i class="fa fa-paint-brush" aria-hidden="true"></i>
					</div>
					<h4>Interior Designs</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
				</div>
			</div>
			<div class="col-xs-4 ser-grid">
				<div class="ser-top">
					<div class="con hvr-shutter-in-horizontal">
						<i class="fa fa-wrench" aria-hidden="true"></i>
					</div>
					<h4>Exterior Designs</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- //services -->
<!-- footer -->
	<?php include_once('inc/footer.php') ?>