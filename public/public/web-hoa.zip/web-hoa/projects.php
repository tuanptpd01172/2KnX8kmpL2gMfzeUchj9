<?php include_once('inc/header.php') ?>
<!-- banner -->
	<div class="banner1 jarallax">
	</div>
<!-- //banner -->	
<!-- projects -->
	<div class="gallery-grids">
		<div class="container">
		<h2 class="w3ls_head"><span>Sản</span> phẩm</h2>
			<p class="w3agile">While designing your living room, it’s a good idea to think about certain key aspects like space available, the colours to be used, the kind of furniture and accessories you fancy.
				</p>
			<div class="show-reel tel-prj">
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s1.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s1.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s2.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s2.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s3.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s3.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s4.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s4.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="show-reel tel-prj-1">
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s5.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s5.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s6.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s6.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s7.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s7.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s8.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s8.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="show-reel">
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s4.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s4.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s8.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s8.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s5.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s5.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-3 agile-gallery-grid">
					<div class="agile-gallery">
						<a href="images/s9.jpg" class="lsb-preview" data-lsb-group="header">
							<img src="images/s9.jpg" alt="" />
							<div class="agileits-caption">
								<h4>Upholstery</h4>
								<p>Sed ultricies non sem sit amet laoreet. Ut semper erat erat.</p>
							</div>
						</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- <script>
				$(window).load(function() {
				  $.fn.lightspeedBox();
				});

			</script> -->
		</div>
	</div>
	<!-- //projects -->

<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="w3_agile_footer_grids">
				<div class="col-md-4 w3_agile_footer_grid">
					<h3>Latest Tweets</h3>
					<ul class="agile_footer_grid_list">
						<li><i class="fa fa-twitter" aria-hidden="true"></i>Nam libero tempore, cum soluta nobis est eligendi optio 
							cumque nihil impedit. <span>1 day ago</span></li>
						<li><i class="fa fa-twitter" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus <a href="mailto:info@mail.com">info@mail.com</a>
							cumque nihil impedit. <span>2 days ago</span></li>
					</ul>
				</div>
				<div class="col-md-4 w3_agile_footer_grid">
					<h3>Navigation</h3>
					<ul class="agileits_w3layouts_footer_grid_list">
						<li><i class="fa fa-angle-double-right" aria-hidden="true"></i><a href="index.html">Home</a></li>
						<li><i class="fa fa-angle-double-right" aria-hidden="true"></i><a href="services.html">Services</a></li>
						<li><i class="fa fa-angle-double-right" aria-hidden="true"></i><a href="projects.html">Projects</a></li>
						<li><i class="fa fa-angle-double-right" aria-hidden="true"></i><a href="contact.html">Contact</a></li>
					</ul>
				</div>
				<div class="col-md-4 w3_agile_footer_grid">
					<h3>Latest Works</h3>
					<div class="w3_agileits_footer_grid_left">
						<a href="#"><img src="images/s6.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="w3_agileits_footer_grid_left">
						<a href="#"><img src="images/s2.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="w3_agileits_footer_grid_left">
						<a href="#"><img src="images/s1.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="w3_agileits_footer_grid_left">
						<a href="#"><img src="images/s3.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="w3_agileits_footer_grid_left">
						<a href="#"><img src="images/s4.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="w3_agileits_footer_grid_left">
						<a href="#"><img src="images/s5.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="w3_newsletter_footer_grids">
				<div class="w3_newsletter_footer_grid_left">
					<form action="#" method="post">
						<input type="email" name="Email" placeholder="Email" required="">
						<input type="submit" value="Send">
					</form>
				</div>
				
				
			</div>
		
			<div class="agileinfo_copyright">
				<p>© 2018 Upholstery. All Rights Reserved | Design by <a href="https://w3layouts.com/">W3layouts</a></p>
			</div>
		</div>
	</div>
<!-- //footer -->
<?php include_once('inc/footer.php') ?>